<?php

$_['heading_title'] = "Event SEO";
